﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Final_Quize.Models
{
    public class Post
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public DateTime PostedOn { get; set; }
        public string Discription { get; set; }
        public int UserId { get; set; }
        public virtual User User { get; set; }
        public int TotalLikes = 0;
        public int totalLikes
        {
            get
            {
                return TotalLikes;
            }
            set => TotalLikes += 1;
        }
        public virtual ICollection<Like> Likes { get; set; }
    }
}