﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Final_Quize.Models;

namespace Final_Quize.Controllers
{
    public class UsersController : Controller
    {
        private DataContext db = new DataContext();

        public ActionResult LikedPosts(User item)
        {
            //We need a page where the user can see all the posts he liked
            var AllPosts = new Dictionary<string, DateTime>();
            var user = db.Users.ToList().First(x => x.Id == item.Id);
            var allLikes = db.Likes.ToList().Where(x => x.UserId == user.Id && x.LikeThis == true).ToList();
            allLikes.ForEach(like =>
            {
                var discription = like.Post.Discription;
                AllPosts.Add(discription, like.Post.PostedOn);
            });
            return View(AllPosts);
        }


        public ActionResult History(User item)
        {
            //We need a page that shows all the posts by a user,
            //under each post, show a list of all comments, then show another list of people who like this post
            var user = db.Users.ToList().First(x => x.Id == item.Id);
            var ListOfPostComments = new Dictionary<int, List<string>>();
            // if a user commented multiple times!!
            var ListOfPostLikes = new Dictionary<int, List<string>>();
            var ListOfPosts = db.Posts.ToList().Where(post => post.UserId == user.Id).ToList();
            if (ListOfPosts.Count == 0)
            {
                return View(ListOfPosts);
            }
            ListOfPosts.ForEach(post =>
            {
                var comments = db.Comments.ToList().Where(x => x.PostId == post.Id).Select(x => x.Discription).ToList();
                var LikedThisPost = post.Likes.ToList();
                var peopleWhoLikedThisPost = new List<string>();
                LikedThisPost.ForEach(like =>
                {
                    peopleWhoLikedThisPost.Add(like.UserName);
                });
                ListOfPostComments.Add(post.Id, comments);
                ListOfPostLikes.Add(post.Id, peopleWhoLikedThisPost);
            });

            ViewBag.ListOfPostLikes = ListOfPostLikes;
            ViewBag.ListOfPostComments = ListOfPostComments;
            return View(ListOfPosts);
        }

        // GET: Users
        public ActionResult Index()
        {
            return View(db.Users.ToList());
        }

        // GET: Users/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // GET: Users/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name")] User user)
        {
            if (ModelState.IsValid)
            {
                db.Users.Add(user);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(user);
        }

        // GET: Users/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name")] User user)
        {
            if (ModelState.IsValid)
            {
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(user);
        }

        // GET: Users/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            User user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
