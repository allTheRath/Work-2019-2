﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RestaurentApp.Models;

namespace RestaurentApp.Controllers
{
    public class ItemCustomersController : Controller
    {
        private DatabaseContext db = new DatabaseContext();

        // GET: ItemCustomers
        public ActionResult Index()
        {
            var itemCustomers = db.ItemCustomers.Include(i => i.Customer).Include(i => i.Item);
            return View(itemCustomers.ToList());
        }

        // GET: ItemCustomers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ItemCustomer itemCustomer = db.ItemCustomers.Find(id);
            if (itemCustomer == null)
            {
                return HttpNotFound();
            }
            return View(itemCustomer);
        }

        // GET: ItemCustomers/Create
        public ActionResult Create()
        {
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name");
            ViewBag.ItemId = new SelectList(db.Items, "Id", "DishName");
            return View();
        }

        // POST: ItemCustomers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CustomerId,ItemId")] ItemCustomer itemCustomer, bool? customerCons)
        {
            if (customerCons != null && customerCons == true)
            {
                if (ModelState.IsValid)
                {
                    db.ItemCustomers.Add(itemCustomer);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return RedirectToAction("MenuItems", "Customers", new { id = itemCustomer.CustomerId });
            }
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name", itemCustomer.CustomerId);
            ViewBag.ItemId = new SelectList(db.Items, "Id", "DishName", itemCustomer.ItemId);
            return View(itemCustomer);
        }

        // GET: ItemCustomers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ItemCustomer itemCustomer = db.ItemCustomers.Find(id);
            if (itemCustomer == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name", itemCustomer.CustomerId);
            ViewBag.ItemId = new SelectList(db.Items, "Id", "DishName", itemCustomer.ItemId);
            return View(itemCustomer);
        }

        // POST: ItemCustomers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,CustomerId,ItemId")] ItemCustomer itemCustomer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(itemCustomer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name", itemCustomer.CustomerId);
            ViewBag.ItemId = new SelectList(db.Items, "Id", "DishName", itemCustomer.ItemId);
            return View(itemCustomer);
        }

        // GET: ItemCustomers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ItemCustomer itemCustomer = db.ItemCustomers.Find(id);
            if (itemCustomer == null)
            {
                return HttpNotFound();
            }
            return View(itemCustomer);
        }

        // POST: ItemCustomers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ItemCustomer itemCustomer = db.ItemCustomers.Find(id);
            db.ItemCustomers.Remove(itemCustomer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
