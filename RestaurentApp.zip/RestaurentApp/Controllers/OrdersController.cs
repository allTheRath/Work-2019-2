﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RestaurentApp.Models;

namespace RestaurentApp.Controllers
{
    public class OrdersController : Controller
    {
        private DatabaseContext db = new DatabaseContext();
        // GET: Orders
        public ActionResult Index()
        {
            var orders = db.Orders.Include(o => o.Customer);
            return View(orders.ToList());
        }

        // GET: Orders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        public ActionResult CreateOrder(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            var itemIds = db.ItemCustomers.Where(x => x.CustomerId == customer.Id).Select(x => x.ItemId).ToList();
            var items = db.Items.Where(x => itemIds.Contains(x.Id)).ToList();
            double total = 0;
            items.ForEach(x =>
            {
                total += x.Price;
            });
            ViewBag.TotalBill = total;
            return View();
        }

        public RedirectToRouteResult AddItemOrder(int itemId, int orderId)
        {
            return RedirectToRoute("CreateOrderItem",new { orderId = orderId, itemId = itemId});
            
        }

        [HttpPost]
        public ActionResult CreateOrder(int? id,[Bind(Include = "Id,CreationTime,IsForPickUp,DelivaryPrice,StatusOfOrder,SpecialRequest")] Order order)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            var itemIds = db.ItemCustomers.Where(x => x.CustomerId == customer.Id).Select(x => x.ItemId).ToList();
            var items = db.Items.Where(x => itemIds.Contains(x.Id)).ToList();
            double total = 0;
            items.ForEach(x =>
            {
                total += x.Price;
            });
            order.Customer = customer;
            order.CustomerId = customer.Id;
            if (ModelState.IsValid)
            { 
                db.Orders.Add(order);
                db.SaveChanges();
                foreach (var i in items)
                {
                    AddItemOrder(i.Id, order.Id);
                }

                return  RedirectToAction("CustomerOrders", "Customers",new { customerId = customer.Id,orderId = order.Id});
            }

            return View(order);
        }

        // GET: Orders/Create
        public ActionResult Create()
        {
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name");
            return View();
        }

        // POST: Orders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CreationTime,IsForPickUp,DelivaryPrice,StatusOfOrder,SpecialRequest,CustomerId")] Order order)
        {
            if (ModelState.IsValid)
            {
                db.Orders.Add(order);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name", order.CustomerId);
            return View(order);
        }

        // GET: Orders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name", order.CustomerId);
            return View(order);
        }

        // POST: Orders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,CreationTime,IsForPickUp,DelivaryPrice,StatusOfOrder,SpecialRequest,CustomerId")] Order order)
        {
            if (ModelState.IsValid)
            {
                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerId = new SelectList(db.Customers, "Id", "Name", order.CustomerId);
            return View(order);
        }

        // GET: Orders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        // POST: Orders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Order order = db.Orders.Find(id);
            db.Orders.Remove(order);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
