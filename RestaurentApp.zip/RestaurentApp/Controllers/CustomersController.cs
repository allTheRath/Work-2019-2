﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RestaurentApp.Models;

namespace RestaurentApp.Controllers
{

    public class CustomersController : Controller
    {
        private DatabaseContext db = new DatabaseContext();
        private ItemCustomersController itemCustomersController = new ItemCustomersController();
        private OrderItemsController orderItemsController = new OrderItemsController();
        private OrdersController ordersController = new OrdersController();

        public ActionResult CustomerOrders(int? customerId, int? orderId)
        {
            if (customerId == null || orderId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(customerId);
            Order order = db.Orders.Find(orderId);
            if (customer == null || order == null)
            {
                return HttpNotFound();
            }
            return View();
        }

        public ActionResult DeleateItemFromOrder(int? id,int? CustomerId)
        {
            if (id == null || CustomerId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(CustomerId);
            Item item = db.Items.Find(id);
            if (customer == null || item == null)
            {
                return HttpNotFound();
            }
            var itemCustomer = db.ItemCustomers.Where(x => x.ItemId == item.Id && x.CustomerId == customer.Id).First();
            db.ItemCustomers.Remove(itemCustomer);
            db.SaveChanges();
            // logic for deleate from order items
            return RedirectToAction("EditOrder",new { id = id });
        }

        public ActionResult EditOrder(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerId = customer.Id;
            var itemIds = db.ItemCustomers.Where(x => x.CustomerId == customer.Id).Select(x => x.ItemId).ToList();
            var items = db.Items.ToList().Where(x => itemIds.Contains(x.Id)).ToList();
            return View(items);
        }

        //[HttpPost]
        //public ActionResult EditOrder(int? id, int? ItemId)
        //{
        //    if (id == null || ItemId == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Customer customer = db.Customers.Find(id);
        //    Item item = db.Items.Find(ItemId);
        //    if (customer == null || item == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    var itemIds = db.ItemCustomers.Where(x => x.CustomerId == customer.Id).Select(x => x.ItemId).ToList();
        //    var items = db.Items.ToList().Where(x => itemIds.Contains(x.Id)).ToList().Distinct();
        //    return View(items);
        //}

        public ActionResult ConfirmOrder(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return RedirectToAction("CreateOrder","Orders",new { id = id});
        }

        public ActionResult MenuItems(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            var menu = db.ItemMenus.ToList();
            var Items = new Dictionary<int, List<Item>>();
            menu.ForEach(m => {
                Items.Add(m.Id, m.Items.ToList());
                });
            ViewBag.Menu = menu;
            ViewBag.customerId = customer.Id;
            return View(Items);
        }

        [HttpPost]
        public ActionResult MenuItems(int? id, int? ItemId)
        {
            if (id == null || ItemId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            Item item = db.Items.Find(ItemId);
            if (customer == null || item == null)
            {
                return HttpNotFound();
            }

            ItemCustomer itemCustomer = new ItemCustomer();
            itemCustomer.ItemId = item.Id;
            itemCustomer.CustomerId = customer.Id;
            itemCustomersController.Create(itemCustomer, true);
            return RedirectToAction("MenuItems", "Customers", new { id = id });
        }

        // GET: Customers
        public ActionResult Index()
        {
            return View(db.Customers.ToList());
        }

        // GET: Customers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // GET: Customers/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,StreetAddress")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Customers.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(customer);
        }

        // GET: Customers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,StreetAddress")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(customer);
        }

        // GET: Customers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Customer customer = db.Customers.Find(id);
            db.Customers.Remove(customer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
