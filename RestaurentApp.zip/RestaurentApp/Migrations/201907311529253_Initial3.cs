namespace RestaurentApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial3 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Customers", "Item_Id", "dbo.Items");
            DropIndex("dbo.Customers", new[] { "Item_Id" });
            CreateTable(
                "dbo.ItemCustomers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CustomerId = c.Int(nullable: false),
                        ItemId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Customers", t => t.CustomerId, cascadeDelete: true)
                .ForeignKey("dbo.Items", t => t.ItemId, cascadeDelete: true)
                .Index(t => t.CustomerId)
                .Index(t => t.ItemId);
            
            DropColumn("dbo.Customers", "Item_Id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Customers", "Item_Id", c => c.Int());
            DropForeignKey("dbo.ItemCustomers", "ItemId", "dbo.Items");
            DropForeignKey("dbo.ItemCustomers", "CustomerId", "dbo.Customers");
            DropIndex("dbo.ItemCustomers", new[] { "ItemId" });
            DropIndex("dbo.ItemCustomers", new[] { "CustomerId" });
            DropTable("dbo.ItemCustomers");
            CreateIndex("dbo.Customers", "Item_Id");
            AddForeignKey("dbo.Customers", "Item_Id", "dbo.Items", "Id");
        }
    }
}
