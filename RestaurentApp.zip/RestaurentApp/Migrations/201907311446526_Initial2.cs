namespace RestaurentApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial2 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Items", "Customer_Id", "dbo.Customers");
            DropIndex("dbo.Items", new[] { "Customer_Id" });
            AddColumn("dbo.Customers", "Item_Id", c => c.Int());
            CreateIndex("dbo.Customers", "Item_Id");
            AddForeignKey("dbo.Customers", "Item_Id", "dbo.Items", "Id");
            DropColumn("dbo.Items", "Customer_Id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Items", "Customer_Id", c => c.Int());
            DropForeignKey("dbo.Customers", "Item_Id", "dbo.Items");
            DropIndex("dbo.Customers", new[] { "Item_Id" });
            DropColumn("dbo.Customers", "Item_Id");
            CreateIndex("dbo.Items", "Customer_Id");
            AddForeignKey("dbo.Items", "Customer_Id", "dbo.Customers", "Id");
        }
    }
}
