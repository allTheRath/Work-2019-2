﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurentApp.Models
{
    public class Item
    {
        public int Id { get; set; }
        public string DishName { get; set; }
        public double Price { get; set; }
        public string SubCatagory { get; set; }
        public string Catagory { get; set; }
        public bool Available { get; set; }
        public int ItemMenuId { get; set; }
        public virtual ICollection<ItemCustomer> ItemCustomers { get; set; }
        public virtual ItemMenu ItemMenu { get; set; }
        public virtual ICollection<OrderItem> OrderItems { get; set; }
    }
}