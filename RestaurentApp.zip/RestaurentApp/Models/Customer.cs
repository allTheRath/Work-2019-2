﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RestaurentApp.Models
{
    public class Customer
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(20, ErrorMessage ="Name can't be that long")]
        [MinLength(3, ErrorMessage = "Name can't be that Short")]
        public string Name { get; set; }
        public string StreetAddress { get; set; }
        public virtual ICollection<ItemCustomer> ItemCustomers { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
        public Customer()
        {
            Orders = new HashSet<Order>();
        }
    }
}