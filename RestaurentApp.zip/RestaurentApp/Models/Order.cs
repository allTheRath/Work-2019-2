﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace RestaurentApp.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime CreationTime { get; set; }
        public bool IsForPickUp { get; set; }
        public double DelivaryPrice { get; set; }
        public string StatusOfOrder { get; set; }
        public string SpecialRequest { get; set; }
        public int CustomerId { get; set; }
        public virtual Customer Customer { get; set; }
        public virtual ICollection<OrderItem> OrderItems { get; set; }
    }
}