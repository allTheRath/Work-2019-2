﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurentApp.ViewModels
{
    public class OrderStatus
    {
        public string BillTotal { get; set; }
         
    }
}