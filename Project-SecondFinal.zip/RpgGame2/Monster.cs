﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RpgGame2
{
    class Monster
    {
        public String Name;
        public int Strength;
        public int Defense;
        public int OriginalHp;
        public int CurrentHp;
        public int EarnPoints;
        public static string HighestYet;
        public static int HighestStrength = 0;
        public Monster(string Name, int Strength, int Defense, int EarnPoints)
        {
            this.Name = Name;
            this.Strength = Strength;
            this.Defense = Defense;
            this.EarnPoints = EarnPoints;
            this.CurrentHp = 100;
            this.OriginalHp = 100;
            if(this.Strength > Monster.HighestStrength)
            {
                Monster.HighestStrength = this.Strength;
                Monster.HighestYet = this.Name;
                //creating a Boss monster
            }
        }
    }
}
