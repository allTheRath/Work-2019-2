﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RpgGame2
{
    class Player 
    {
        public string Name;
        public int Strength;
        public int Defense;
        public int OriginalHp;
        public int CurrentHp;
        public int HitPoints;
        public int Coins;
        public Weapon EquipedWeapon;
        public Armor EquipedArmor;
        public List<Armor> ArmorsBag;
        public List<Weapon> WeaponsBag;
        public Player(string Name)
        {
            this.Name = Name;
            this.Strength = 100;
            this.Defense = 100;
            this.OriginalHp = 100;
            // implement hp from app.config at the end
            this.CurrentHp = 100;
            this.HitPoints = 0;
            this.Coins = 200;
            WeaponsBag = new List<Weapon>();
            ArmorsBag = new List<Armor>();
            // initilize EquipedWeapon and EquipedArmor at the time in game.
        }

        public void ShowStats()
        {
            //health defence hit points
            Console.WriteLine("Health: {0}HP \n Defense: {1}SP\n HitPoints: {2}", this.CurrentHp, this.Defense, this.HitPoints);
        }

        public void ShowInventory()
        {
            if(this.WeaponsBag != null && this.WeaponsBag.Count > 0)
            {
                Console.WriteLine("List of Weapons in Inventory: \n");
                this.WeaponsBag.ForEach(weapon => Console.WriteLine("Weapon : {0} Power: {1} Equiped: {2}", weapon.Name, weapon.Power, weapon.equiped));

            } else
            {
                Console.WriteLine("You don't have any Weapons Please Buy some.\n");
            }
            if(this.WeaponsBag != null && this.ArmorsBag.Count > 0)
            {
                Console.WriteLine("List of Armors in Inventory: \n");
                this.ArmorsBag.ForEach(armor => Console.WriteLine("armor : {0} Power: {1} Equiped: {2}", armor.Name, armor.Power, armor.equiped));

            }
            else
            {
                Console.WriteLine("You don't have any Armors Please Buy some.\n");
            }

        }

        public void EquipWeapon(Weapon EquipeThisWeapon)
        {
            this.EquipedWeapon = EquipeThisWeapon;
            this.EquipedWeapon.equiped = true;
            //this.WeaponsBag.Where(weapon => weapon.Name == EquipedWeapon.Name).ToList()[0].equiped = true;
            this.WeaponsBag.ForEach(weapon =>
            {
                if (weapon.Name == EquipedWeapon.Name)
                {
                    weapon.equiped = true;
                } else
                {
                    weapon.equiped = false;
                }
            });
        }

        public void EquipArmor(Armor EquipeThisArmor)
        {
            this.EquipedArmor = EquipeThisArmor;
            this.EquipedArmor.equiped = true;
            this.ArmorsBag.ForEach(armor =>
            {
                if (armor.Name == EquipedArmor.Name)
                {
                    armor.equiped = true;
                }
                else
                {
                    armor.equiped = false;
                }
            });
        }

        public void AddWeaponInBag(Weapon addToTheBag)
        {
            this.WeaponsBag.Add(addToTheBag);
            Game.ListOfWeapons.ForEach(weapon =>
            {
                if(weapon.Name == addToTheBag.Name && weapon.Power == addToTheBag.Power)
                {
                    weapon.IHave = true;
                }
            });
        }

        public void AddArmorInBag(Armor addToTheBag)
        {
            this.ArmorsBag.Add(addToTheBag);
            Game.ListOfArmors.ForEach(armor =>
            {
                if (armor.Name == addToTheBag.Name && armor.Power == addToTheBag.Power)
                {
                    armor.IHave = true;
                }
            });
        }
    }

}
