﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RpgGame2
{
    class Game
    {
        public static List<Monster> ListOfMonsters = new List<Monster>();
        public static List<Weapon> ListOfWeapons = new List<Weapon>();
        public static List<Armor> ListOfArmors = new List<Armor>();
        public Player player;
        public Monster currentMonster;
        int TurnCounter;
        int PlayerGamePoints; //incrementing points for later adding rewards

        public void BuyFromAllWeapons()
        {
            // player money is reduce. AddWeaponInBag(Armor)
            // player inventory of weaponsbag is called with this weapon

            int i = 0;
        Chose:
            ListOfWeapons.ForEach(weapon =>
            {
                Console.WriteLine("For selecting below weapon press: {0} ", i);
                Console.WriteLine("Weapon: {0} Power: {1} Price: {2} I Have: {3} \n", weapon.Name, weapon.Power, weapon.Price, weapon.IHave);
                i++;
            });
            try
            {
                i = Convert.ToInt32(Console.ReadLine());
                if (player.Coins >= ListOfWeapons[i].Price)
                {
                    player.Coins -= ListOfWeapons[i].Price;
                    player.AddWeaponInBag(ListOfWeapons[i]);
                    Console.WriteLine("Would you like to equipe this weapon: press y-\n");
                    if(Console.ReadLine().ToString() == "y")
                    {
                        player.EquipWeapon(ListOfWeapons[i]);
                    }
                }
                else
                {
                    throw new Exception("You have less coins");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Would you like to buy Other weapons: press -y");
                string Operation3 = Console.ReadLine().ToString();
                if (Operation3 == "y")
                {
                    i = 0;
                    Console.Clear();
                    goto Chose;

                }
                else
                {
                    Console.WriteLine("Exiting\n");
                    Console.Clear();
                }
            }


        }

        public void BuyFromAllArmors()
        {
            // player money is reduce. players AddArmorInBag(weapon )
            // player inventory of armorsbag is called with this armor


            int i = 0;
        Chose:
            ListOfArmors.ForEach(armor =>
            {
                Console.WriteLine("For selecting below armor press: {0} ", i);
                Console.WriteLine("armor: {0} Power: {1} Price: {2} I Have: {3} \n", armor.Name, armor.Power, armor.Price, armor.IHave);
                i++;
            });
            try
            {
                i = Convert.ToInt32(Console.ReadLine());
                if (player.Coins >= ListOfArmors[i].Price)
                {
                    player.Coins -= ListOfArmors[i].Price;
                    player.AddArmorInBag(ListOfArmors[i]);
                    Console.WriteLine("Would you like to equipe this Armor: press y-\n");
                    if (Console.ReadLine().ToString() == "y")
                    {
                        player.EquipArmor(ListOfArmors[i]);
                    }
                }
                else
                {
                    throw new Exception("You have less coins");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Would you like to buy Other Armor: press -y");
                string Operation3 = Console.ReadLine().ToString();
                if (Operation3 == "y")
                {
                    i = 0;
                    Console.Clear();
                    goto Chose;

                }
                else
                {
                    Console.WriteLine("Exiting\n");
                    Console.Clear();
                }
            }
        }

        public void CheckingPlayerInventory()
        {
            player.ShowInventory();
            // player's ShowInventory()
        }

        public static void PlayerTurn(Player p, Monster m)
        {
            // add buy extra health.
            // add buy extra armor.
            // add weapon use count and decrement it and provide ability to increment it.
            // add strength use.
            // add monster weapons.
            if (m.Defense >= p.EquipedWeapon.Power)
            {
                m.Defense -= p.EquipedWeapon.Power;
                Console.WriteLine("Monster defended and has {2} defence left by weapon {0} of {1} Power",p.EquipedWeapon.Name, p.EquipedWeapon.Power, m.Defense );
            }
            else
            {
                int LeftOfAttack = p.EquipedWeapon.Power - m.Defense;
                Console.WriteLine("You have destroyed his defense.\n");
                m.Defense = 0;
                if (LeftOfAttack <= m.CurrentHp)
                {
                    m.CurrentHp -= LeftOfAttack;
                    Console.WriteLine("Monsters helth left is : {0}", m.CurrentHp);

                }
                else
                {
                    m.CurrentHp = 0;
                    p.HitPoints += m.EarnPoints;
                    Console.WriteLine("You have defeted {0}. Your current health is {1} .\n You have Earned {2} Coins\n", m.Name, p.CurrentHp, m.EarnPoints);
                }
            }
            p.HitPoints += m.Strength / 10;
            Console.WriteLine("you have earned {0} points from attack.", m.Strength / 10);
            Console.WriteLine("------------------\n");
            p.ShowStats();
            Console.WriteLine("------------------\n");
            Console.WriteLine("Would you like to buy extra health: 1 or extra Armor: 2 or Defense: 3 or Press any Key to Continue:\n ");
            try
            {
                int option = Convert.ToInt32(Console.ReadLine());
                if(option == 1)
                {
                    if(p.CurrentHp < 100)
                    {
                        p.Coins -= 5;
                        p.CurrentHp += 20;
                        Console.WriteLine("Your Health is now at {0}", p.CurrentHp);
                        Console.WriteLine("changing turn.");
                    }
                } else if(option == 2)
                {
                    p.Coins -= 5;
                    p.EquipedArmor.Power += 20;
                    Console.WriteLine("Your armor strength is at {0}", p.EquipedArmor.Power);
                    Console.WriteLine("changing turn.");
                } else if(option == 3)
                {
                    if(p.Defense < 100)
                    {
                        p.Coins -= 5;
                        p.Defense += 20;
                        Console.WriteLine("Your Defense strength is at {0}", p.Defense);
                        Console.WriteLine("changing turn.");
                    }
                }
                else
                {
                    Console.WriteLine("changing turn.");
                }
            } catch(Exception e)
            {
                Console.WriteLine("changing turn.");
            }

        }

        public static void MonsterTurn(Player p, Monster m)
        {
            if (p.EquipedArmor != null && p.EquipedArmor.Power >= m.Strength)
            {
                p.EquipedArmor.Power -= m.Strength;
                Console.WriteLine("Your Armor of {0} is at Strength of {1}.", p.EquipedArmor.Name, p.EquipedArmor.Power);        
            }
            else
            {
                int leftAttackStrength = 0;
                if (p.EquipedArmor != null)
                {
                    leftAttackStrength = m.Strength - p.EquipedArmor.Power;
                    p.EquipedArmor.Power = 0;
                    Console.WriteLine("You have lost your Armor.\n");
                } else
                {
                    leftAttackStrength = m.Strength;
                }
                
                if (leftAttackStrength <= p.Defense)
                {
                    p.Defense -= leftAttackStrength;
                    Console.WriteLine("You have defended the attack. But Your Defense is at : {0}\n", p.Defense);
                }
                else
                {
                    int leftAttackStrength2 = leftAttackStrength - p.Defense;
                    p.Defense = 0;
                    Console.WriteLine("You have no Defense\n");
                    if (leftAttackStrength2 <= p.CurrentHp)
                    {
                        p.CurrentHp -= leftAttackStrength2;
                        Console.WriteLine("You have Defended the attack but your current health is at : {0} HP", p.CurrentHp);
                    }
                    else
                    {
                        p.CurrentHp = 0;
                        Console.WriteLine("Monster {0} won but you damaged it. His Health is {1}\n", m.Name, m.CurrentHp);
                    }
                }
            }
            Console.WriteLine("Enter any key to continue.\n");
            Console.ReadLine();
        }

        public void Fight()
        {

            Console.WriteLine("Would you like to fight the Strongest: press y\n");
            string Operation5 = Console.ReadLine().ToString();
            if (Operation5 == "y")
            {
                ListOfMonsters.ForEach(monster =>
                {
                    if (monster.Name == Monster.HighestYet && monster.Strength == Monster.HighestStrength)
                    {
                        currentMonster = monster;
                    }
                });

            }
            else
            {
                currentMonster = ListOfMonsters[new Random().Next(0, ListOfMonsters.Count)];

            }

            if(currentMonster.monsterWeapon == null)
            {
                // adding weapon to the monster based on level.
            }

            Console.Clear();
            // player can have or not Equiped Armor but weapon is must.
            if (player.EquipedWeapon != null)
            {

                Console.WriteLine("Fight will Begin in 3 2 1 : Go\n");
                int playerTurnCount = new Random().Next(0, 1);
            // if 0 then player is first else Monster is first.
            ContinueGame:
                if (playerTurnCount == 0)
                {
                    PlayerTurn(player, currentMonster);
                    playerTurnCount = 1;
                }
                else if (playerTurnCount == 1)
                {
                    MonsterTurn(player, currentMonster);
                    playerTurnCount = 0;
                }
                if (player.CurrentHp > 0 && currentMonster.CurrentHp > 0)
                {
                    goto ContinueGame;
                }
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("You should Equip your self.");
            }
        }

        public void SelectWeaponForFightFromPlayerInventory()
        {
            if(player.WeaponsBag != null && player.WeaponsBag.Count != 0)
            {
                int i = 0;
            Chose:
                player.WeaponsBag.ForEach(weapon =>
                {
                    Console.WriteLine("For selecting below weapon press: {0} ", i);
                    Console.WriteLine("weapon: {0} Power: {1} \n", weapon.Name, weapon.Power);
                    i++;
                });
                try
                {
                    i = Convert.ToInt32(Console.ReadLine());
                    if (i >= 0)
                    {
                        player.EquipWeapon(player.WeaponsBag[i]);
                    }
                    else
                    {
                        Console.WriteLine("Wrong input\n");
                        Console.WriteLine("Try again\n");
                        goto Chose;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            } else
            {
                Console.WriteLine("You don't have any weapons.");
            }
            
        }

        public void SelectArmorForFightFromPlayerInventory()
        {
            if (player.ArmorsBag != null && player.ArmorsBag.Count != 0)
            {
                int i = 0;
            Chose:
                player.ArmorsBag.ForEach(armor =>
                {
                    Console.WriteLine("For selecting below armor press: {0} ", i);
                    Console.WriteLine("armor : {0} Power: {1} \n", armor.Name, armor.Power);
                    i++;
                });
                try
                {
                    i = Convert.ToInt32(Console.ReadLine());
                    if (i >= 0)
                    {
                        player.EquipArmor(player.ArmorsBag[i]);
                    }
                    else
                    {
                        Console.WriteLine("Wrong input\n");
                        Console.WriteLine("Try again\n");
                        goto Chose;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            else
            {
                Console.WriteLine("You don't have any weapons.");
            }
        }

        public void MainMenu()
        {
        MainMenu:
            Console.Clear();
            try
            {
                Console.WriteLine("{0} you have {1} Coins", player.Name, player.Coins);
                player.ShowStats();
                Console.WriteLine("Press 0: for Checking Your Weapons and Armors\n");
                Console.WriteLine("Press 1: for Buying Weapons from Inventory\n");
                Console.WriteLine("Press 2: for Buying Armors from Inventory\n");
                Console.WriteLine("Press 3: for Go to Fight:\n");
                Console.WriteLine("Press 4: for Selecting Weapon From your inventory:\n");
                Console.WriteLine("Press 5: for Selecting Armor From your inventory:\n");
                Console.WriteLine("Press 6: for Exit:\n");

                int Operation = Convert.ToInt32(Console.ReadLine());
                switch (Operation)
                {
                    case 0:
                        CheckingPlayerInventory();
                        break;
                    case 1:
                        BuyFromAllWeapons();
                        break;
                    case 2:
                        BuyFromAllArmors();
                        break;
                    case 3:
                        Fight();
                        player.CurrentHp = 100;
                        player.Defense = 100;
                        //player.EquipedArmor.Power = 100;
                        player.ShowStats();
                        Console.WriteLine("Player is healed from previous game.");
                        break;
                    case 4:
                        SelectWeaponForFightFromPlayerInventory();
                        break;
                    case 5:
                        SelectArmorForFightFromPlayerInventory();
                        break;
                    case 6:
                        Console.WriteLine("Exiting the game\n");
                        break;
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("Would you like to go to Main Manu: press- y\n");
            string Operation2 = Console.ReadLine().ToString();
            if (Operation2 == "y")
            {
                goto MainMenu;
            }
            else
            {
                Console.WriteLine("Exiting the game");
            }

        }
        public void Start()
        {
        PlayerNameInit:
            Console.WriteLine("Welcome to RPG game.\n\n\n");
            Console.WriteLine("Enter Name:\n");
            string name = Console.ReadLine();
            int firstLater = Convert.ToInt32(name[0]);
            if ((firstLater >= 65 && firstLater <= 90) || (firstLater >= 97 && firstLater <= 122))
            {
                this.player = new Player(name);
            }
            else
            {
                Console.WriteLine("Player name should start with alphbet\n");
                Console.WriteLine("Try again:\n");
                goto PlayerNameInit;
            }

            Console.WriteLine("Initilizing Monsters and Inventory\n");
            ListOfMonsters.Add(new Monster("The Kraken", 100, 200, 50));
            ListOfMonsters.Add(new Monster("Murloc", 20, 100, 5));
            ListOfMonsters.Add(new Monster("Reaper", 25, 120, 7));
            ListOfMonsters.Add(new Monster("Dark Ganon", 35, 130, 10));
            ListOfMonsters.Add(new Monster("Frieza", 45, 140, 12));
            ListOfMonsters.Add(new Monster("Vegita", 55, 150, 14));
            ListOfMonsters.Add(new Monster("Darkspawn Ogre", 65, 160, 16));
            ListOfMonsters.Add(new Monster("Creeper", 75, 170, 18));
            // ordering the monsters on 
            ListOfMonsters.OrderBy(x => x.Strength);

            ListOfArmors.Add(new Armor("shield of fortune", 20, 15));
            ListOfArmors.Add(new Armor("shield of Zortan", 15, 13));
            ListOfArmors.Add(new Armor("shield of Agnor", 40, 25));
            ListOfArmors.Add(new Armor("shield of Rah", 50, 20));
            ListOfArmors.Add(new Armor("shield of Sun", 65, 23));
            ListOfArmors.Add(new Armor("shield of Wildlings", 60, 40));
            ListOfArmors.Add(new Armor("shield of Man", 80, 50));
            ListOfArmors.Add(new Armor("shield of Love", 90, 65));

            ListOfWeapons.Add(new Weapon("Gun", 10, 5));
            ListOfWeapons.Add(new Weapon("Axe", 20, 10));
            ListOfWeapons.Add(new Weapon("Hex saw", 30, 15));
            ListOfWeapons.Add(new Weapon("Lightning", 40, 20));
            ListOfWeapons.Add(new Weapon("Laser", 45, 25));
            ListOfWeapons.Add(new Weapon("Macheteee", 50, 30));
            ListOfWeapons.Add(new Weapon("Computer", 60, 40));
            ListOfWeapons.Add(new Weapon("Match stick", 100, 110));

            Console.WriteLine("Initilization completed.\n");
            Console.Clear();
            MainMenu();
            Console.WriteLine("Buy Buy {0}\n", this.player.Name);
            // initilize every thing.
            // call main menu.
        }
    }
}
