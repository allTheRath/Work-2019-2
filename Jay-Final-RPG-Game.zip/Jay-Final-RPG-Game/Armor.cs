﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RpgGame2
{
    class Armor
    {
        public string Name;
        public int Power;
        public bool equiped;
        public int Price;
        public bool IHave;
        public Armor(string Name, int Power, int Price)
        {
            this.Name = Name;
            this.Power = Power;
            this.equiped = false;
            this.Price = Price;
            this.IHave = false;
        }

    }
}
