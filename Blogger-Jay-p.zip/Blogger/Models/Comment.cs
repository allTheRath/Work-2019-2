﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Blogger.Models
{
    public class Comment
    {
        public int ID { get; set; }
        public string Content { get; set; }
        public string Author { get; set; }
        public bool Accepeted = false;
        public string TitelOfBlog { get; set; }
        public string Email { get; set; }
        public DateTime TimeOfCreation = DateTime.Now.Date;
    }
    public class CommentContext : DbContext
    {
        public DbSet<Comment> Comments { get; set; }
    }
}