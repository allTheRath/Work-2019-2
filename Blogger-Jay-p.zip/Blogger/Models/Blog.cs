﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Blogger.Models
{
    public class Blog
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public DateTime CreationDay;
        private string Tags = "";

        public string tags{
            get => Tags;
            
            set => Tags += " " + value;

            // each tag is divided by " "
        }
    }
    public class BlogContext : DbContext
    {
        public DbSet<Blog> Blogs { get; set; }
    }
}