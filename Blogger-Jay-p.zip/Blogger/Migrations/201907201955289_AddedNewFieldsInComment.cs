namespace Blogger.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedNewFieldsInComment : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Comments", "Email", c => c.String());
            DropColumn("dbo.Comments", "Accepeted");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Comments", "Accepeted", c => c.Boolean(nullable: false));
            DropColumn("dbo.Comments", "Email");
        }
    }
}
