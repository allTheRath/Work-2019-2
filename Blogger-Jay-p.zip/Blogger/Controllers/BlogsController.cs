﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Blogger.Models;

namespace Blogger.Controllers
{
    public class BlogsController : Controller
    {
        private BlogContext db = new BlogContext();
        private CommentContext comment = new CommentContext();


        public ActionResult OrderByDate()
        {
            //-	A page to display each tag with the number of blogs in this tag.
            ViewBag.Comments = comment.Comments.ToList();
            var orderedBlogs = db.Blogs.ToList().OrderBy(blog => blog.CreationDay);
            return View(orderedBlogs);
        }

        public ActionResult NotAccepetedComments()
        {
            //-	A page to display each tag with the number of blogs in this tag.
            var notAccepetedComments = comment.Comments.ToList().Where(comment => comment.Accepeted == false);
            return View(notAccepetedComments);
        }

        public ActionResult ListOfYears(int Year = 0)
        {
            //A page which contains a list of years, when you press a year, you go to a page that displays all the blogs 
            //in this year
            comment.Comments.ToList().ForEach(comment => comment.Accepeted = true);
            ViewBag.Comments = comment.Comments.ToList();
            var ListOfYears = db.Blogs.ToList().Select(x => x.CreationDay.Year).Distinct();
            ViewBag.Year = new SelectList(ListOfYears);
            if (Year == 0)
            {
                return View(db.Blogs.ToList());
            }
            else
            {
                return View(db.Blogs.ToList().Where(blog => blog.CreationDay.Year == Year));
            }
        }

        public ActionResult ListOfTags(string Tags = "")
        {
            //-	A page which contains a list of tags, when you press a tag, you go to a page that displays all the blogs 
            //in this tag
            ViewBag.Comments = comment.Comments.ToList();
            var allTagString = db.Blogs.ToList().Select(x => x.tags);
            List<string> allTagList = new List<string>();
            allTagString.ToList().ForEach(tagString =>
            {
                string subString = "";
                for (int i = 0; i < tagString.Length; i++)
                {
                    if (Convert.ToChar(tagString[i]) == Convert.ToChar(" "))
                    {
                        if (!allTagList.Contains(subString))
                        {
                            allTagList.Add(subString);

                        }
                        subString = "";
                    }
                    else
                    {
                        subString += tagString[i];
                    }
                }
            }
            );

            ViewBag.Tags = new SelectList(allTagList);
            if (Tags == "")
            {
                return View(db.Blogs.ToList());
            }
            else
            {
                var allBlogs = db.Blogs.ToList().Where(b => b.tags.Contains(Tags));
                return View(allBlogs);
            }
        }

        public ActionResult MostBlogsBasedOnTag()
        {
            //A page that displays the Tag with most blogs along the blogs of this tag, like the Tag “Action” has
            //the highest number of blogs in the website
 
            ViewBag.Comments = comment.Comments.ToList();
            var allTagString = db.Blogs.ToList().Select(x => x.tags);
            Dictionary<string, int> allTagList = new Dictionary<string, int>();
            allTagString.ToList().ForEach(tagString =>
            {
                string subString = "";
                for (int i = 0; i < tagString.Length; i++)
                {
                    if (Convert.ToChar(tagString[i]) == Convert.ToChar(" "))
                    {
                        if(allTagList.ContainsKey(subString))
                        {
                            allTagList[subString] += 1;
                        } else
                        {
                            allTagList.Add(subString, 1);
                        }
                        subString = "";
                    }
                    else
                    {
                        subString += tagString[i];
                    }
                }
            }
            );

            var HighestAccuringTag = allTagList.OrderByDescending(x => x.Value).Select(x => x.Key);
            var MostViewedBlog = db.Blogs.ToList().Select(blog => blog.tags.Contains(HighestAccuringTag.ToString()));
            ViewBag.MostCommanTag = HighestAccuringTag.ToString();
            ViewBag.Comments = comment.Comments.ToList();
            //passing comments
            return View(MostViewedBlog);
        }

        public ActionResult EachTagWithNumberOfBlogs()
        {
            //-	A page to display each tag with the number of blogs in this tag.
            var allTagString = db.Blogs.ToList().Select(x => x.tags);
            Dictionary<string, int> allTagList = new Dictionary<string, int>();
            allTagString.ToList().ForEach(tagString =>
            {
                string subString = "";
                for (int i = 0; i < tagString.Length; i++)
                {
                    if (Convert.ToChar(tagString[i]) == Convert.ToChar(" "))
                    {
                        if (allTagList.ContainsKey(subString))
                        {
                            allTagList[subString] += 1;
                        }
                        else
                        {
                            allTagList.Add(subString, 1);
                        }
                        subString = "";
                    }
                    else
                    {
                        subString += tagString[i];
                    }
                }
            }
            );
            ViewBag.DictionaryOfAccurence = allTagList;
            return View();
        }





        // GET: Blogs
        public ActionResult Index()
        {
            // Each time index page is rendered all comments will be accepted.
            // all Blogs should be Ordered by date of publishing

            comment.Comments.ToList().ForEach(comment => comment.Accepeted = true);
            ViewBag.Comments = comment.Comments.ToList();
            var orderedBlogs = db.Blogs.ToList().OrderBy(blog => blog.CreationDay);
            return View(orderedBlogs);
        }

        // GET: Blogs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Blog blog = db.Blogs.Find(id);
            if (blog == null)
            {
                return HttpNotFound();
            }
            return View(blog);
        }

        // GET: Blogs/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Blogs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Title,Content,Tags")] Blog blog)
        {
            var IsItThere = db.Blogs.Where(x => x.Title == blog.Title).ToList().Count;

            if (ModelState.IsValid && IsItThere == 0)
            {
                //adding creation date as datetime object
                blog.CreationDay = DateTime.Now;
                db.Blogs.Add(blog);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            //blog.Title = "There is a Blog with the name" + blog.Title;
            return View(blog);
        }

        // GET: Blogs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Blog blog = db.Blogs.Find(id);
            if (blog == null)
            {
                return HttpNotFound();
            }
            return View(blog);
        }

        // POST: Blogs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Title,Content,Tags")] Blog blog)
        {
            if (ModelState.IsValid)
            {
                db.Entry(blog).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(blog);
        }

        // GET: Blogs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Blog blog = db.Blogs.Find(id);
            if (blog == null)
            {
                return HttpNotFound();
            }
            return View(blog);
        }

        // POST: Blogs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Blog blog = db.Blogs.Find(id);
            db.Blogs.Remove(blog);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
