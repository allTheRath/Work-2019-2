﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication_mvc.Models
{
    public class Car
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Trim { get; set; }
        public string make { get; set; }
        public int Year { get; set; }
        public int Price { get; set; }
    }

    public class CarsContext : DbContext
    {
        public DbSet<Car> AllCars { get; set; }
    }
}