﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication_mvc.Models
{
    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public DateTime dateOfBirth { get; set; }
        public string Country { get; set; }
    }

    public class StudentsContext : DbContext
    {
        public DbSet<Student> AllStudents { get; set; }
    }
}