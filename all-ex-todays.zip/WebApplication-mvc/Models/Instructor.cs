﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplication_mvc.Models
{
    public class Instructor
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string FieldOfStudy { get; set; }
    }

    public class InstructorsContext : DbContext
    {
        DbSet<Instructor> AllInstructors { get; set; }

        public System.Data.Entity.DbSet<WebApplication_mvc.Models.Instructor> Instructors { get; set; }

        public System.Data.Entity.DbSet<WebApplication_mvc.Models.Student> Students { get; set; }
    }
}