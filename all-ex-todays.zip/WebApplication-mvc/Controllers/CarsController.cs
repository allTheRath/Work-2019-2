﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication_mvc.Models;

namespace WebApplication_mvc.Controllers
{
    public class CarsController : Controller
    {
        private CarsContext db = new CarsContext();
        // get chepest car made before int year
        public ActionResult Chepest(int year)
        {
            var carObj1 = db.AllCars.Where(car => car.Year <= year).ToList();
            int min = carObj1.Min(car => car.Price);
            Car carObj = carObj1.Find(car => car.Price == min);
            List<Car> cars = new List<Car>();
            cars.Add(carObj);
            return View(cars);
        }

        public ActionResult Expensive()
        {
            var carObj1 = db.AllCars.Max(car => car.Price);
            var carObj = db.AllCars.ToList().Find(car => car.Price == carObj1);
            List<Car> cars = new List<Car>();
            cars.Add(carObj);
            return View(cars);
        }

        public ActionResult ExpensiveTrim(string trim)
        {
            var carObj1 = db.AllCars.Where(car => car.Trim == trim).Max(car => car.Price);
            var carObj = db.AllCars.ToList().Find(car => car.Price == carObj1);
            List<Car> cars = new List<Car>();
            cars.Add(carObj);
            return View(cars);
        }

        public ActionResult MadeAfter(int year)
        {
            var carObj = db.AllCars.Where(car => car.Year >= year).ToList();
            return View(carObj);
        }

        public ActionResult MadeAfterTrim(int year, string trim)
        {
            var carObj = db.AllCars.Where(car => car.Year >= year).ToList();
            var trimed = carObj.Find(car => car.Trim == trim);
            List<Car> cars = new List<Car>();
            cars.Add(trimed);
            return View(cars);
        }

        public ActionResult Make(string make)
        {
            var carObj = db.AllCars.Where(car => car.make == make).ToList();
            return View(carObj);
        }



        // GET: Cars
        public ActionResult Index()
        {
            return View(db.AllCars.ToList());
        }

        // GET: Cars/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.AllCars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            return View(car);
        }

        // GET: Cars/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Cars/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Name,Trim,make,Year,Price")] Car car)
        {
            if (ModelState.IsValid)
            {
                db.AllCars.Add(car);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(car);
        }

        // GET: Cars/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.AllCars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            return View(car);
        }

        // POST: Cars/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name,Trim,make,Year,Price")] Car car)
        {
            if (ModelState.IsValid)
            {
                db.Entry(car).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(car);
        }

        // GET: Cars/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car car = db.AllCars.Find(id);
            if (car == null)
            {
                return HttpNotFound();
            }
            return View(car);
        }

        // POST: Cars/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Car car = db.AllCars.Find(id);
            db.AllCars.Remove(car);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
