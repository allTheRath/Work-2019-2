namespace E_Commerce_Ex.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FirstTryForRelations : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.MultipleProducts",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ItemName = c.String(),
                        ItemPrice = c.String(),
                        ExpectedOn = c.DateTime(nullable: false),
                        MultipleProducts_Id = c.Int(),
                        Cart_CartId = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.MultipleProducts", t => t.MultipleProducts_Id)
                .ForeignKey("dbo.Carts", t => t.Cart_CartId)
                .Index(t => t.MultipleProducts_Id)
                .Index(t => t.Cart_CartId);
            
            CreateTable(
                "dbo.Quantities",
                c => new
                    {
                        QuantityId = c.Int(nullable: false),
                        Amount = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.QuantityId)
                .ForeignKey("dbo.Products", t => t.QuantityId)
                .Index(t => t.QuantityId);
            
            CreateTable(
                "dbo.Orders",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        OrderedOn = c.DateTime(nullable: false),
                        ProductId = c.Int(nullable: false),
                        Cart_CartId = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Products", t => t.ProductId, cascadeDelete: true)
                .ForeignKey("dbo.Carts", t => t.Cart_CartId)
                .Index(t => t.ProductId)
                .Index(t => t.Cart_CartId);
            
            AddColumn("dbo.Customers", "MultipleProducts_Id", c => c.Int());
            CreateIndex("dbo.Customers", "MultipleProducts_Id");
            AddForeignKey("dbo.Customers", "MultipleProducts_Id", "dbo.MultipleProducts", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Products", "Cart_CartId", "dbo.Carts");
            DropForeignKey("dbo.Orders", "Cart_CartId", "dbo.Carts");
            DropForeignKey("dbo.Orders", "ProductId", "dbo.Products");
            DropForeignKey("dbo.Customers", "MultipleProducts_Id", "dbo.MultipleProducts");
            DropForeignKey("dbo.Products", "MultipleProducts_Id", "dbo.MultipleProducts");
            DropForeignKey("dbo.Quantities", "QuantityId", "dbo.Products");
            DropIndex("dbo.Orders", new[] { "Cart_CartId" });
            DropIndex("dbo.Orders", new[] { "ProductId" });
            DropIndex("dbo.Quantities", new[] { "QuantityId" });
            DropIndex("dbo.Products", new[] { "Cart_CartId" });
            DropIndex("dbo.Products", new[] { "MultipleProducts_Id" });
            DropIndex("dbo.Customers", new[] { "MultipleProducts_Id" });
            DropColumn("dbo.Customers", "MultipleProducts_Id");
            DropTable("dbo.Orders");
            DropTable("dbo.Quantities");
            DropTable("dbo.Products");
            DropTable("dbo.MultipleProducts");
        }
    }
}
