﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_Commerce_Ex.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public string ItemPrice { get; set; }
        public DateTime ExpectedOn { get; set; }
        public virtual Quantity Quantity { get; set; }
    }
}
// actionresult of addtocart 