﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace E_Commerce_Ex.Models
{
    public class Cart
    {
        [ForeignKey("Customer")]
        public int CartId { get; set; }
        public virtual Customer Customer { get; set; }
        public ICollection<Product> Products { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
    }
   
}

// flow of connection:-
// in reality only one customer at a time like login and after login customer get a main page of all products
// customer has ability to search based on product name or specific product. 
// customer has ability to add the product to cart.
// in cart customer can confirm order. and payment
// also need an access to quantity table to get updated quantity because in real life multiple people
// can at a time see the products

    
//Buy this product .. 
// customer has a cart-
// customer is connected to multipleProducts page
// mulTiple Products page has ability to add to cart.
// cart contains multiple products 
// order a product from cart -- confirm payment!
// cart contains order
// order takes a single product
// order can have one or multiple products in it. but atleast one product

// product is only releted to MultipleProducts
// add product to the cart so cart will have collection of products
