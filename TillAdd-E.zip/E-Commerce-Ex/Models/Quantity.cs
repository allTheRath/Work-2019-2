﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace E_Commerce_Ex.Models
{
    public class Quantity
    {
        [ForeignKey("Product")]
        public int QuantityId { get; set; }
        public int Amount { get; set; }
        public virtual Product Product { get; set; }
    }
}