﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace E_Commerce_Ex.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string Province { get; set; }
        public virtual Cart Cart { get; set; }
        public virtual MultipleProducts MultipleProducts { get; set; }
        //view multiple product page / add to cart for MultipleProducts
        // got to my cart
        // show products in cart
        // show order the single product
        // order multiple products.
        // after confirmation of order cart will will have a ordered product but it will be shown in purchased products.
        // a list of purchased products.

        //public virtual ICollection<Product> Products { get; set; }
    }
}


//relations :-
// quantity 1-1 product
// customer 1-1 cart
// customer 1-many MultipleProducts
// MultipleProducts has a list of products but product is not one-many with MultipleProducts