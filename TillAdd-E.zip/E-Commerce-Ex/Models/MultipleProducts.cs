﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace E_Commerce_Ex.Models
{
    public class MultipleProducts
    {
        public int Id { get; set; }
        public virtual ICollection<Product> Products { get; set; }
        // product quantity table so that i can show all available quantity of a product
       // and on each order confirmation quantity will be decrese for given product.
        // get products to show.
        // by default it should show some different types of products.
        // based on customer previous search i can send a collection of mostlikable products.
        // or basd on a search option like books i can send a collection of mostLikable products.
    }
}