﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace E_Commerce_Ex.Models
{
    public class DatabaseContext3 : DbContext
    {
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<MultipleProducts> MultipleProducts { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Quantity> Quantities { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>()
                .HasRequired(x => x.Cart);
            modelBuilder.Entity<Product>()
                .HasRequired(x => x.Quantity);
        }

    }

    
}