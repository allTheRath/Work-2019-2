﻿using System;
using System.Collections.Generic;

namespace Quize_Question1_8_15_2019
{
    public class Question1
    {
        public int NotRepetedElement(int[] array)
        {
            Dictionary<int, bool> repetedValues = new Dictionary<int, bool>();
            for (int i = 0; i < array.Length; i++)
            {
                if (repetedValues.ContainsKey(array[i]))
                {
                    repetedValues[array[i]] = false;
                }
                else
                {
                    repetedValues.Add(array[i], false);
                }
            }
            foreach (var pair in repetedValues)
            {
                if (pair.Value == true)
                {
                    return pair.Key;
                }
            }
            return 0;
        }

        public bool ContainsDuplicatedValues(int[] array)
        {
            int[] tempArray = array;
            for (int i = 0; i < array.Length; i++)
            {
                int element = array[i];
                for (int j = i; j < tempArray.Length; j++)
                {
                    if (tempArray[j] == element)
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public bool ContainsDuplicatedValuesWithSets(int[] array)
        {
            HashSet<int> hashValues = new HashSet<int>();
            for (int i = 0; i < array.Length; i++)
            {
                if (hashValues.Contains(array[i]))
                {
                    return false;
                }
                else
                {
                    hashValues.Add(array[i]);
                }
            }

            return true;
        }

    }

    public class Program
    {
       

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
