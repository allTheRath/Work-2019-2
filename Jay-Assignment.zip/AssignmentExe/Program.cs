﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArrayOp;

namespace AssignmentExe
{
    class Program
    {
        static void Main(string[] args)
        {
            //MyArrayProcessor
            Console.WriteLine("Assignment-1 by Jay\n");
            Int32[] array1 = new Int32[] { 1, 32, 1243, -123, 123, 0192, 4, -23, 21, 32, 1243, 32, 123, -123, 4, 4, 4, -23, -23, 123, -23, -23 };
            Int32[] array2 = new Int32[] { 4, 4, -23 };
            Console.WriteLine("----for finding frequncy of given number---\n");
            int test1 = MyArrayProcessor.Frequency(array1, 32);
            Console.WriteLine("Output1 {0}", test1);
            // above repetative value is present
            int test2 = MyArrayProcessor.Frequency(array2, -4);
            Console.WriteLine("Output for value not present",test2);
            // here value does not exist in the array.
            Console.WriteLine("--------------------------");

            Console.WriteLine("----for reversing of given test---\n");
            Int32[] test3 = MyArrayProcessor.Reverse(array1);
            int array1Len = array1.Length;
            // if array length is odd then to make sure if it has same values.
            bool flag = true;
            for (int i = 0; i < array1Len; i++)
            {
                
                if(test3[i] != array1[array1Len - i - 1])
                {
                    flag = false;            
                    Console.WriteLine("test failed. ");
                } else
                {
                    Console.WriteLine("test array element at {0} {1} and reversed array at {2} {3}", i, test3[i], i, array1[array1Len - i - 1]);
                }
            }
            Console.WriteLine("Output1 :{0}", flag);
            // above repetative value is present
            int test4 = MyArrayProcessor.Frequency(array2, -4);
            Console.WriteLine("Output2 for value not present: {0}",test4);
            // here value does not exist in the array.
            Console.WriteLine("\n-------------------------- Finding highest frequncy number of test array\n");

            Console.WriteLine(MyArrayProcessor.HighestFrequency(array1));

            Console.WriteLine(MyArrayProcessor.HighestFrequency(array2));
            Console.ReadLine();
        }
    }
}
