﻿using System;

namespace ArrayOp
{
    public class MyArrayProcessor
    {
        public static int Frequency(Int32[] array, Int32 value)
        {
            int frequncy = 0;
            for(int i = 0; i < array.Length; i++)
            {
                if(array[i] == value)
                {
                    frequncy++;
                }
            }
            return frequncy;
        }
        public static Int32[] Reverse(Int32[] array)
        {
            Int32[] reversedArray = new Int32[array.Length];
            int j = 0;
            for (int i = array.Length - 1; i >=0; i--)
            {
                reversedArray[j] = array[i];
                j++;
            }
            return reversedArray;
        }
        public static int HighestFrequency(Int32[] array)
        {
            int highest = 0, highestNumber = 0;
            for(int i = 0; i < array.Length; i++)
            {
                int frequncy = Frequency(array, array[i]);
                if (frequncy > highest)
                {
                    highest = frequncy;
                    highestNumber = array[i];
                }
            }
            return highestNumber;
        }
    }
}
