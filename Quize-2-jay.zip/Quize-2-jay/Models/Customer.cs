﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Quize_2_jay.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string LocalAddress { get; set; }
        public int? ItemMenuId { get; set; }
        public virtual ItemMenu ItemMenu { get; set; }
// items are the selected items for order
        public ICollection<Item> Items { get; set; }
        public virtual ICollection<Order> Orders { get;set; }
    }
}