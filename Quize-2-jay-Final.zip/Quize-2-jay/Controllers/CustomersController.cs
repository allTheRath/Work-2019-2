﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Quize_2_jay.Models;

namespace Quize_2_jay.Controllers
{
    public class CustomersController : Controller
    {
        private DatabaseContext db = new DatabaseContext();

        public ActionResult ConfirmOrders(int? CustomerId)
        {
            int id = (int)CustomerId;
            var customer = db.Customers.Find(id);
            //inverse ids _ are stored.
            List<Item> Items = customer.Items.ToList();
            return View(Items);
        }

        public ActionResult MenuItems(int? id)
        {
            ViewBag.CustomerId = id;
            return View(db.ItemMenus.ToList());
        }

        [HttpPost]
        public ActionResult MenuItems(int dishId, dynamic CustomerId)
        {
            DatabaseContext db = new DatabaseContext();
            // each time initilizes new context..
            string a = CustomerId[0].ToString();
            string c = a.Substring(a.IndexOf("=") + 1);
            int secondEnd = c.IndexOf("}");
            string val = "";
            for(int j = 0; j < secondEnd; j++)
            {
                val += c[j];
            }
            var customer = db.Customers.Find(Convert.ToInt32(val));
            var dish = db.Items.Find(dishId);
            if (dish.Available == true)
            {
                if (customer.Items == null)
                {
                    customer.Items = new HashSet<Item>();
                }

                customer.Items.Add(dish);
                CustomerItem entry = new CustomerItem();
                entry.CId = Convert.ToInt32(val);
                entry.IId = dishId;
                var itemCustomerList = db.CustomerItems.ToList();
                itemCustomerList.Add(entry);
                db.SaveChanges();
            }
            var id = CustomerId;
            return RedirectToAction("MenuItems", id);
        }

        // GET: Customers
        public ActionResult Index()
        {
            var customers = db.Customers.Include(c => c.ItemMenu);
            return View(customers.ToList());
        }

        // GET: Customers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // GET: Customers/Create
        public ActionResult Create()
        {
            //ViewBag.ItemMenuId = new SelectList(db.ItemMenus, "Id", "MenuTitle");
            return View();
        }

        // POST: Customers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,LocalAddress")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                customer.ItemMenuId = null;
                db.Customers.Add(customer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            //ViewBag.ItemMenuId = new SelectList(db.ItemMenus, "Id", "MenuTitle", customer.ItemMenuId);
            return View(customer);
        }

        // GET: Customers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            //ViewBag.ItemMenuId = new SelectList(db.ItemMenus, "Id", "MenuTitle", customer.ItemMenuId);
            return View(customer);
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,LocalAddress")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            //ViewBag.ItemMenuId = new SelectList(db.ItemMenus, "Id", "MenuTitle", customer.ItemMenuId);
            return View(customer);
        }

        // GET: Customers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer customer = db.Customers.Find(id);
            if (customer == null)
            {
                return HttpNotFound();
            }
            return View(customer);
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Customer customer = db.Customers.Find(id);
            db.Customers.Remove(customer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
