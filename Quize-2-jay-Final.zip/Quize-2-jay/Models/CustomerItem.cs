﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quize_2_jay.Models
{
    public class CustomerItem
    {
        public int Id { get; set; }
        public int CId { get; set; }
        public int IId { get; set; }
    }
}