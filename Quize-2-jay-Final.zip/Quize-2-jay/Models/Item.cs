﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quize_2_jay.Models
{
    public class Item
    {
        public int Id { get; set; }
        public string DishName { get; set; }
        public int MinutesToMake { get; set; }
        public double Price { get; set; }
        public bool Available { get; set; }
        public double DeliveryCharge { get; set; }
        public virtual ICollection<Customer> Customers { get; set; }
        public int ItemMenuId { get; set; }
        public virtual ItemMenu ItemMenu { get; set; }
    }
}