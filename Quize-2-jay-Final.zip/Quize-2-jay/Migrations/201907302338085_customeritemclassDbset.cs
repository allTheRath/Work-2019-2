namespace Quize_2_jay.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class customeritemclassDbset : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CustomerItems",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CustomerId = c.Int(nullable: false),
                        ItemId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.CustomerItems");
        }
    }
}
