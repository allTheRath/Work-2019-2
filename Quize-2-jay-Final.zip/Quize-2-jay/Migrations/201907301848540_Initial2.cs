namespace Quize_2_jay.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial2 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Customers", "ItemMenuId", "dbo.ItemMenus");
            DropIndex("dbo.Customers", new[] { "ItemMenuId" });
            AlterColumn("dbo.Customers", "ItemMenuId", c => c.Int());
            CreateIndex("dbo.Customers", "ItemMenuId");
            AddForeignKey("dbo.Customers", "ItemMenuId", "dbo.ItemMenus", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Customers", "ItemMenuId", "dbo.ItemMenus");
            DropIndex("dbo.Customers", new[] { "ItemMenuId" });
            AlterColumn("dbo.Customers", "ItemMenuId", c => c.Int(nullable: false));
            CreateIndex("dbo.Customers", "ItemMenuId");
            AddForeignKey("dbo.Customers", "ItemMenuId", "dbo.ItemMenus", "Id", cascadeDelete: true);
        }
    }
}
