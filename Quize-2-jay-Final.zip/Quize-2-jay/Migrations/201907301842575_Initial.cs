namespace Quize_2_jay.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        LocalAddress = c.String(),
                        ItemMenuId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.ItemMenus", t => t.ItemMenuId, cascadeDelete: true)
                .Index(t => t.ItemMenuId);
            
            CreateTable(
                "dbo.ItemMenus",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        MenuTitle = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Items",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        DishName = c.String(),
                        MinutesToMake = c.Int(nullable: false),
                        Price = c.Double(nullable: false),
                        Available = c.Boolean(nullable: false),
                        DeliveryCharge = c.Double(nullable: false),
                        ItemMenuId = c.Int(nullable: false),
                        Customer_Id = c.Int(),
                        Order_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.ItemMenus", t => t.ItemMenuId, cascadeDelete: true)
                .ForeignKey("dbo.Customers", t => t.Customer_Id)
                .ForeignKey("dbo.Orders", t => t.Order_Id)
                .Index(t => t.ItemMenuId)
                .Index(t => t.Customer_Id)
                .Index(t => t.Order_Id);
            
            CreateTable(
                "dbo.Orders",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        TimeOfOrder = c.DateTime(nullable: false),
                        CustomerId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Customers", t => t.CustomerId, cascadeDelete: true)
                .Index(t => t.CustomerId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Items", "Order_Id", "dbo.Orders");
            DropForeignKey("dbo.Orders", "CustomerId", "dbo.Customers");
            DropForeignKey("dbo.Items", "Customer_Id", "dbo.Customers");
            DropForeignKey("dbo.Items", "ItemMenuId", "dbo.ItemMenus");
            DropForeignKey("dbo.Customers", "ItemMenuId", "dbo.ItemMenus");
            DropIndex("dbo.Orders", new[] { "CustomerId" });
            DropIndex("dbo.Items", new[] { "Order_Id" });
            DropIndex("dbo.Items", new[] { "Customer_Id" });
            DropIndex("dbo.Items", new[] { "ItemMenuId" });
            DropIndex("dbo.Customers", new[] { "ItemMenuId" });
            DropTable("dbo.Orders");
            DropTable("dbo.Items");
            DropTable("dbo.ItemMenus");
            DropTable("dbo.Customers");
        }
    }
}
