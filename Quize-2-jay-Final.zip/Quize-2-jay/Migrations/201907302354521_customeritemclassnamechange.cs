namespace Quize_2_jay.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class customeritemclassnamechange : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.CustomerItems", "CId", c => c.Int(nullable: false));
            AddColumn("dbo.CustomerItems", "IId", c => c.Int(nullable: false));
            DropColumn("dbo.CustomerItems", "CustomerId");
            DropColumn("dbo.CustomerItems", "ItemId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.CustomerItems", "ItemId", c => c.Int(nullable: false));
            AddColumn("dbo.CustomerItems", "CustomerId", c => c.Int(nullable: false));
            DropColumn("dbo.CustomerItems", "IId");
            DropColumn("dbo.CustomerItems", "CId");
        }
    }
}
