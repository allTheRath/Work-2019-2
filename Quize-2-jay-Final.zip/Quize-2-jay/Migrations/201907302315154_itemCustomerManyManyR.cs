namespace Quize_2_jay.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class itemCustomerManyManyR : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Items", "Customer_Id", "dbo.Customers");
            DropIndex("dbo.Items", new[] { "Customer_Id" });
            CreateTable(
                "dbo.ItemCustomers",
                c => new
                    {
                        Item_Id = c.Int(nullable: false),
                        Customer_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Item_Id, t.Customer_Id })
                .ForeignKey("dbo.Items", t => t.Item_Id, cascadeDelete: true)
                .ForeignKey("dbo.Customers", t => t.Customer_Id, cascadeDelete: true)
                .Index(t => t.Item_Id)
                .Index(t => t.Customer_Id);
            
            DropColumn("dbo.Items", "Customer_Id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Items", "Customer_Id", c => c.Int());
            DropForeignKey("dbo.ItemCustomers", "Customer_Id", "dbo.Customers");
            DropForeignKey("dbo.ItemCustomers", "Item_Id", "dbo.Items");
            DropIndex("dbo.ItemCustomers", new[] { "Customer_Id" });
            DropIndex("dbo.ItemCustomers", new[] { "Item_Id" });
            DropTable("dbo.ItemCustomers");
            CreateIndex("dbo.Items", "Customer_Id");
            AddForeignKey("dbo.Items", "Customer_Id", "dbo.Customers", "Id");
        }
    }
}
